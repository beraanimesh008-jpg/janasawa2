import * as React from 'react';
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CardType, CARD_PROBLEM_TYPES, CARD_SPECIFIC_FIELDS } from '../types';
import { createRequest } from '../services/storage';
import { ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react';

const ServiceForm: React.FC = () => {
  const { cardType } = useParams<{ cardType: string }>();
  const navigate = useNavigate();
  
  const decodedCardType = cardType ? decodeURIComponent(cardType) as CardType : CardType.AADHAAR;

  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    mobile: '',
    village: '',
    address: '',
    problemType: '',
  });

  const [additionalData, setAdditionalData] = useState<Record<string, string>>({});

  useEffect(() => {
    // Reset additional data when card type changes
    setAdditionalData({});
    setFormData(prev => ({ ...prev, problemType: '' }));
  }, [decodedCardType]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAdditionalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAdditionalData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (!formData.problemType) {
        throw new Error("Please select a problem type.");
      }

      await createRequest({
        cardType: decodedCardType,
        problemType: formData.problemType,
        customer: {
          fullName: formData.fullName,
          mobile: formData.mobile,
          village: formData.village,
          address: formData.address,
        },
        additionalDetails: additionalData
      });

      setSuccess(true);
      window.scrollTo(0,0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4 text-center animate-fade-in">
        <div className="bg-green-100 p-4 rounded-full mb-4">
          <CheckCircle className="w-16 h-16 text-green-600" />
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Request Submitted!</h2>
        <p className="text-slate-600 max-w-md mb-8">
          Your request for {decodedCardType} service has been successfully recorded. 
          We have sent a confirmation to <strong>{formData.mobile}</strong>.
          Our team will review your details and update you shortly.
        </p>
        <button
          onClick={() => navigate('/')}
          className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700 transition shadow-lg"
        >
          Return to Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button 
        onClick={() => navigate('/')}
        className="flex items-center text-slate-500 hover:text-indigo-600 mb-6 transition"
      >
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Services
      </button>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
        <div className="bg-indigo-600 px-8 py-6">
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            {decodedCardType} Application
          </h1>
          <p className="text-indigo-100 mt-1 text-sm">Fill in the details below to submit your request.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          {/* Section 1: Problem Selection */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">1. Select Issue</h3>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Problem Type <span className="text-red-500">*</span></label>
              <select
                name="problemType"
                value={formData.problemType}
                onChange={handleInputChange}
                className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 px-3 border bg-slate-50"
                required
              >
                <option value="">-- Select Problem Type --</option>
                {CARD_PROBLEM_TYPES[decodedCardType]?.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Section 2: Card Specific Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">2. Card Specific Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {CARD_SPECIFIC_FIELDS[decodedCardType]?.map((field) => (
                <div key={field.key} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{field.label}</label>
                  <input
                    type={field.type}
                    name={field.key}
                    placeholder={field.placeholder}
                    value={additionalData[field.key] || ''}
                    onChange={handleAdditionalChange}
                    className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 px-3 border"
                  />
                </div>
              ))}
              {/* Fallback if no specific fields defined, though all are covered in types */}
              {(!CARD_SPECIFIC_FIELDS[decodedCardType] || CARD_SPECIFIC_FIELDS[decodedCardType].length === 0) && (
                 <p className="text-sm text-slate-500 italic">No additional specific details required for this card type.</p>
              )}
            </div>
          </div>

          {/* Section 3: Customer Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">3. Applicant Details (Contact)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                  placeholder="As per documents"
                  className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 px-3 border"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Mobile Number <span className="text-red-500">*</span></label>
                <input
                  type="tel"
                  name="mobile"
                  value={formData.mobile}
                  onChange={handleInputChange}
                  required
                  pattern="[0-9]{10}"
                  placeholder="10 digit number"
                  className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 px-3 border"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Village/City</label>
                <input
                  type="text"
                  name="village"
                  value={formData.village}
                  onChange={handleInputChange}
                  placeholder="Enter village or city"
                  className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 px-3 border"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Address <span className="text-red-500">*</span></label>
                <textarea
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  required
                  rows={3}
                  placeholder="House No, Street, Landmark, Pin Code"
                  className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 px-3 border"
                />
              </div>
            </div>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isLoading ? 'Submitting...' : 'Submit Request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ServiceForm;