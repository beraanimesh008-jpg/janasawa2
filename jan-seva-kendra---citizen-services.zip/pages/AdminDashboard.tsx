import * as React from 'react';
import { useEffect, useState } from 'react';
import { getRequests, updateRequestStatus, deleteRequest } from '../services/storage';
import { ServiceRequest, RequestStatus, CardType } from '../types';
import { format } from 'date-fns';
import { 
  Filter, 
  Search, 
  Eye, 
  Trash2, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Loader,
  RefreshCw
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [filteredRequests, setFilteredRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);

  // Filters
  const [filterCard, setFilterCard] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');

  // Protect Route
  useEffect(() => {
    const isAdmin = localStorage.getItem('isAdmin');
    if (!isAdmin) {
      navigate('/admin/login');
    }
  }, [navigate]);

  const loadData = async () => {
    setLoading(true);
    const data = await getRequests();
    setRequests(data);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    let result = requests;

    if (filterCard !== 'All') {
      result = result.filter(r => r.cardType === filterCard);
    }
    if (filterStatus !== 'All') {
      result = result.filter(r => r.status === filterStatus);
    }
    if (searchTerm) {
      const lowerTerm = searchTerm.toLowerCase();
      result = result.filter(r => 
        r.customer.fullName.toLowerCase().includes(lowerTerm) || 
        r.customer.mobile.includes(lowerTerm) ||
        r.id.toLowerCase().includes(lowerTerm)
      );
    }
    setFilteredRequests(result);
  }, [requests, filterCard, filterStatus, searchTerm]);

  const handleStatusUpdate = async (id: string, newStatus: RequestStatus) => {
    await updateRequestStatus(id, newStatus);
    // Optimistic update
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
    if (selectedRequest && selectedRequest.id === id) {
      setSelectedRequest(prev => prev ? { ...prev, status: newStatus } : null);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this request?')) {
      await deleteRequest(id);
      setRequests(prev => prev.filter(r => r.id !== id));
      if (selectedRequest?.id === id) setSelectedRequest(null);
    }
  };

  const getStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case RequestStatus.APPROVED:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Approved</span>;
      case RequestStatus.REJECTED:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Rejected</span>;
      case RequestStatus.IN_PROGRESS:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">In Progress</span>;
      default:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Pending</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8 md:flex md:items-center md:justify-between">
        <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
        <button 
          onClick={loadData}
          className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50"
        >
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        {[
          { label: 'Total Requests', value: requests.length, color: 'bg-indigo-500' },
          { label: 'Pending', value: requests.filter(r => r.status === RequestStatus.PENDING).length, color: 'bg-yellow-500' },
          { label: 'Approved', value: requests.filter(r => r.status === RequestStatus.APPROVED).length, color: 'bg-green-500' },
          { label: 'Rejected', value: requests.filter(r => r.status === RequestStatus.REJECTED).length, color: 'bg-red-500' },
        ].map((stat) => (
          <div key={stat.label} className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className={`flex-shrink-0 rounded-md p-3 ${stat.color}`}>
                  <LayoutDashboard className="h-6 w-6 text-white" /> 
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-slate-500 truncate">{stat.label}</dt>
                    <dd className="text-lg font-medium text-slate-900">{stat.value}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">Search</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search by name, ID or mobile..."
                className="pl-10 block w-full rounded-md border-slate-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm py-2 border"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Card Type</label>
            <div className="relative">
                <Filter className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <select
                className="pl-10 block w-full rounded-md border-slate-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm py-2 border"
                value={filterCard}
                onChange={(e) => setFilterCard(e.target.value)}
                >
                <option value="All">All Cards</option>
                {Object.values(CardType).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Status</label>
            <select
              className="block w-full rounded-md border-slate-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm py-2 border"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <option value="All">All Statuses</option>
              {Object.values(RequestStatus).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        {loading ? (
          <div className="p-12 flex justify-center text-slate-500">
             <Loader className="animate-spin w-8 h-8" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID / Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Customer</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Service</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="relative px-6 py-3">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredRequests.length === 0 ? (
                    <tr>
                        <td colSpan={5} className="px-6 py-12 text-center text-slate-500">No requests found.</td>
                    </tr>
                ) : (
                    filteredRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-slate-50 transition">
                        <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-indigo-600">#{req.id}</div>
                        <div className="text-sm text-slate-500">
                            {req.createdAt ? format(new Date(req.createdAt), 'MMM d, yyyy') : 'N/A'}
                        </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-slate-900">{req.customer.fullName}</div>
                        <div className="text-sm text-slate-500">{req.customer.mobile}</div>
                        </td>
                        <td className="px-6 py-4">
                        <div className="text-sm text-slate-900 font-medium">{req.cardType}</div>
                        <div className="text-sm text-slate-500 truncate max-w-xs">{req.problemType}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(req.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button 
                            onClick={() => setSelectedRequest(req)}
                            className="text-indigo-600 hover:text-indigo-900 mr-4"
                        >
                            <Eye className="w-5 h-5" />
                        </button>
                        <button 
                            onClick={() => handleDelete(req.id)}
                            className="text-red-600 hover:text-red-900"
                        >
                            <Trash2 className="w-5 h-5" />
                        </button>
                        </td>
                    </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selectedRequest && (
        <div className="fixed z-50 inset-0 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-slate-500 bg-opacity-75 transition-opacity" aria-hidden="true" onClick={() => setSelectedRequest(null)}></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-slate-900 flex justify-between items-center" id="modal-title">
                      Request Details #{selectedRequest.id}
                      {getStatusBadge(selectedRequest.status)}
                    </h3>
                    <div className="mt-4 border-t border-slate-200 pt-4 space-y-3 text-sm">
                      <div className="grid grid-cols-2 gap-2">
                        <span className="font-semibold text-slate-600">Card Type:</span>
                        <span>{selectedRequest.cardType}</span>
                        
                        <span className="font-semibold text-slate-600">Problem Type:</span>
                        <span>{selectedRequest.problemType}</span>

                        <span className="font-semibold text-slate-600">Customer Name:</span>
                        <span>{selectedRequest.customer.fullName}</span>

                        <span className="font-semibold text-slate-600">Mobile:</span>
                        <span>{selectedRequest.customer.mobile}</span>

                        <span className="font-semibold text-slate-600">Village:</span>
                        <span>{selectedRequest.customer.village || 'N/A'}</span>

                        <span className="font-semibold text-slate-600">Address:</span>
                        <span className="break-words">{selectedRequest.customer.address}</span>
                      </div>

                      {Object.keys(selectedRequest.additionalDetails).length > 0 && (
                        <div className="mt-4 bg-slate-50 p-3 rounded">
                            <h4 className="font-semibold mb-2 text-indigo-700">Specific Details</h4>
                            <div className="grid grid-cols-2 gap-2">
                                {Object.entries(selectedRequest.additionalDetails).map(([key, val]) => (
                                    <React.Fragment key={key}>
                                        <span className="font-medium text-slate-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                                        <span>{val}</span>
                                    </React.Fragment>
                                ))}
                            </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-slate-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  onClick={() => setSelectedRequest(null)}
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-slate-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-slate-700 hover:bg-slate-50 focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                >
                  Close
                </button>
                {selectedRequest.status === RequestStatus.PENDING && (
                    <>
                        <button
                        onClick={() => handleStatusUpdate(selectedRequest.id, RequestStatus.REJECTED)}
                        className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                        >
                        <XCircle className="w-4 h-4 mr-2" /> Reject
                        </button>
                        <button
                        onClick={() => handleStatusUpdate(selectedRequest.id, RequestStatus.APPROVED)}
                        className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                        >
                        <CheckCircle className="w-4 h-4 mr-2" /> Approve
                        </button>
                    </>
                )}
                 {selectedRequest.status === RequestStatus.APPROVED && (
                    <button
                    onClick={() => handleStatusUpdate(selectedRequest.id, RequestStatus.IN_PROGRESS)}
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                    >
                    <Clock className="w-4 h-4 mr-2" /> Mark In Progress
                    </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function LayoutDashboard({ className }: { className?: string }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
    )
}

export default AdminDashboard;