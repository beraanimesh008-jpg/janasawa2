import * as React from 'react';
import { Link } from 'react-router-dom';
import { CardType } from '../types';
import { CreditCard, Fingerprint, FileText, ShoppingBasket, ArrowRight } from 'lucide-react';

const cards = [
  {
    type: CardType.AADHAAR,
    icon: Fingerprint,
    color: 'text-rose-600',
    bg: 'bg-rose-50',
    border: 'border-rose-200',
    desc: 'Update Name, Address, Biometrics, and corrections.',
  },
  {
    type: CardType.VOTER,
    icon: FileText,
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    desc: 'Apply new, link mobile, update photo and address.',
  },
  {
    type: CardType.PAN,
    icon: CreditCard,
    color: 'text-emerald-600',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    desc: 'Correction, lost card recovery, and signature updates.',
  },
  {
    type: CardType.RATION,
    icon: ShoppingBasket,
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    desc: 'Add members, change head of family, new application.',
  },
];

const Home: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-extrabold text-slate-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
          Digital Citizen Services
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-500">
          Select a service card below to apply for updates, corrections, or new registrations easily online.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <div
            key={card.type}
            className={`relative group bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-indigo-500 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 border ${card.border}`}
          >
            <div>
              <span className={`rounded-lg inline-flex p-3 ring-4 ring-white ${card.bg} ${card.color}`}>
                <card.icon className="h-8 w-8" aria-hidden="true" />
              </span>
            </div>
            <div className="mt-8">
              <h3 className="text-lg font-medium">
                <Link to={`/apply/${encodeURIComponent(card.type)}`} className="focus:outline-none">
                  <span className="absolute inset-0" aria-hidden="true" />
                  {card.type}
                </Link>
              </h3>
              <p className="mt-2 text-sm text-slate-500">
                {card.desc}
              </p>
            </div>
            <span
              className="pointer-events-none absolute top-6 right-6 text-slate-300 group-hover:text-slate-400"
              aria-hidden="true"
            >
              <ArrowRight className="h-6 w-6" />
            </span>
          </div>
        ))}
      </div>

      <div className="mt-20 bg-white rounded-2xl shadow-lg p-8 md:p-12 border border-slate-100">
        <div className="lg:flex lg:items-center lg:justify-between">
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Track Your Application
            </h2>
            <p className="mt-3 text-lg text-slate-500">
              Already applied? Contact our support or login to check status.
              <br/>
              <span className="text-sm italic mt-2 block text-indigo-500">
                * SMS notifications are sent automatically upon status change.
              </span>
            </p>
          </div>
          <div className="mt-8 lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <button
                disabled
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-slate-400 cursor-not-allowed"
              >
                Check Status (Coming Soon)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;