import { ServiceRequest, RequestStatus } from '../types';

const STORAGE_KEY = 'jan_seva_requests';

// Helper to simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getRequests = async (): Promise<ServiceRequest[]> => {
  await delay(300); // Simulate API latency
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const createRequest = async (request: Omit<ServiceRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Promise<ServiceRequest> => {
  await delay(500);
  const requests = await getRequests();
  
  const newRequest: ServiceRequest = {
    ...request,
    id: Math.random().toString(36).substr(2, 9),
    status: RequestStatus.PENDING,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  requests.unshift(newRequest); // Add to top
  localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
  
  // Simulate sending Admin Notification
  console.log(`[Admin Notification]: New request received for ${newRequest.cardType} from ${newRequest.customer.fullName}`);
  
  return newRequest;
};

export const updateRequestStatus = async (id: string, status: RequestStatus): Promise<void> => {
  await delay(300);
  const requests = await getRequests();
  const updatedRequests = requests.map(req => 
    req.id === id 
      ? { ...req, status, updatedAt: new Date().toISOString() } 
      : req
  );
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedRequests));

  // Simulate sending User Notification
  const req = updatedRequests.find(r => r.id === id);
  if (req) {
     console.log(`[User Notification]: SMS/Email sent to ${req.customer.mobile}. Status updated to ${status}.`);
  }
};

export const deleteRequest = async (id: string): Promise<void> => {
  await delay(300);
  const requests = await getRequests();
  const filteredRequests = requests.filter(req => req.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filteredRequests));
};